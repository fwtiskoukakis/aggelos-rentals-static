<?php
/**
 * Custom WordPress Static Site Exporter with Full SEO Support
 * 
 * This script exports your WordPress site to static HTML files while preserving
 * all SEO metadata (Yoast SEO, Rank Math, etc.) without requiring a subscription.
 * 
 * @package CustomStaticExporter
 * @version 1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    // If accessed directly, try to load WordPress
    $wp_load_path = __DIR__ . '/../../../../wp-load.php';
    if (file_exists($wp_load_path)) {
        require_once($wp_load_path);
    } else {
        die('WordPress not found. This file must be loaded as a mu-plugin.');
    }
}

class CustomStaticExporter {
    private $export_dir;
    private $site_url;
    private $processed_urls = [];
    private $urls_to_process = [];
    private $base_domain;
    
    public function __construct() {
        $this->site_url = home_url();
        $this->base_domain = parse_url($this->site_url, PHP_URL_HOST);
        $timestamp = date('Y-m-d-His');
        $this->export_dir = WP_CONTENT_DIR . '/uploads/static-export-' . $timestamp . '/';
        
        // Create export directory
        if (!file_exists($this->export_dir)) {
            wp_mkdir_p($this->export_dir);
        }
    }
    
    /**
     * Main export function
     */
    public function export() {
        $this->log("Starting static site export...");
        $this->log("Export directory: " . $this->export_dir);
        
        // Get all URLs to export
        $this->log("Collecting URLs to export...");
        $this->collect_urls();
        $this->log("Found " . count($this->urls_to_process) . " URLs to export");
        
        // Export each URL
        $count = 0;
        foreach ($this->urls_to_process as $url) {
            $count++;
            $this->log("Exporting [$count/" . count($this->urls_to_process) . "]: $url");
            $this->export_url($url);
            
            // Add small delay to avoid overwhelming the server
            usleep(100000); // 0.1 second
        }
        
        // Export sitemaps
        $this->log("Exporting sitemaps...");
        $this->export_sitemaps();
        
        // Export robots.txt
        $this->log("Exporting robots.txt...");
        $this->export_robots();
        
        // Copy assets
        $this->log("Copying assets...");
        $this->copy_assets();
        
        // Fix relative URLs
        $this->log("Fixing relative URLs...");
        $this->fix_relative_urls();
        
        $this->log("Export complete! Files saved to: " . $this->export_dir);
        return $this->export_dir;
    }
    
    /**
     * Collect all URLs to export
     */
    private function collect_urls() {
        // Homepage
        $this->urls_to_process[] = home_url('/');
        
        // All pages
        $pages = get_pages(array('post_status' => 'publish', 'number' => -1));
        foreach ($pages as $page) {
            $this->urls_to_process[] = get_permalink($page->ID);
        }
        
        // All posts
        $posts = get_posts(array(
            'post_status' => 'publish',
            'numberposts' => -1,
            'post_type' => 'post'
        ));
        foreach ($posts as $post) {
            $this->urls_to_process[] = get_permalink($post->ID);
        }
        
        // WooCommerce products
        if (class_exists('WooCommerce')) {
            $products = get_posts(array(
                'post_type' => 'product',
                'post_status' => 'publish',
                'numberposts' => -1
            ));
            foreach ($products as $product) {
                $this->urls_to_process[] = get_permalink($product->ID);
            }
            
            // Shop page
            $shop_page_id = wc_get_page_id('shop');
            if ($shop_page_id) {
                $this->urls_to_process[] = get_permalink($shop_page_id);
            }
            
            // Product categories
            $product_cats = get_terms(array(
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
            ));
            if (!is_wp_error($product_cats)) {
                foreach ($product_cats as $cat) {
                    $this->urls_to_process[] = get_term_link($cat);
                }
            }
        }
        
        // Custom post types
        $post_types = get_post_types(array('public' => true, '_builtin' => false), 'names');
        foreach ($post_types as $post_type) {
            if ($post_type === 'product') continue; // Already handled
            
            $items = get_posts(array(
                'post_type' => $post_type,
                'post_status' => 'publish',
                'numberposts' => -1
            ));
            foreach ($items as $item) {
                $this->urls_to_process[] = get_permalink($item->ID);
            }
        }
        
        // Categories
        $categories = get_categories(array('hide_empty' => false));
        foreach ($categories as $category) {
            $this->urls_to_process[] = get_category_link($category->term_id);
        }
        
        // Tags
        $tags = get_tags(array('hide_empty' => false));
        foreach ($tags as $tag) {
            $this->urls_to_process[] = get_tag_link($tag->term_id);
        }
        
        // Remove duplicates and invalid URLs
        $this->urls_to_process = array_unique($this->urls_to_process);
        $this->urls_to_process = array_filter($this->urls_to_process, function($url) {
            return !empty($url) && strpos($url, $this->base_domain) !== false;
        });
    }
    
    /**
     * Export a single URL
     */
    private function export_url($url) {
        if (in_array($url, $this->processed_urls)) {
            return;
        }
        
        // Get the HTML content using WordPress's internal functions
        // This ensures all SEO plugins have processed the page
        $response = wp_remote_get($url, array(
            'timeout' => 60,
            'sslverify' => false,
            'cookies' => $_COOKIE, // Preserve cookies for logged-in content if needed
            'headers' => array(
                'User-Agent' => 'Mozilla/5.0 (compatible; StaticExporter/1.0)'
            )
        ));
        
        if (is_wp_error($response)) {
            $this->log("Error fetching $url: " . $response->get_error_message());
            return;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            $this->log("Skipping $url (HTTP $status_code)");
            return;
        }
        
        $html = wp_remote_retrieve_body($response);
        
        if (empty($html)) {
            $this->log("Empty response for $url");
            return;
        }
        
        // Convert absolute URLs to relative
        $html = $this->convert_urls_to_relative($html, $url);
        
        // Determine file path
        $path = $this->url_to_path($url);
        $file_path = $this->export_dir . $path;
        
        // Create directory if needed
        $dir = dirname($file_path);
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }
        
        // Save file
        file_put_contents($file_path, $html);
        
        $this->processed_urls[] = $url;
    }
    
    /**
     * Convert URL to file path
     */
    private function url_to_path($url) {
        $parsed = parse_url($url);
        $path = isset($parsed['path']) ? $parsed['path'] : '/';
        
        if ($path === '/' || $path === '') {
            return 'index.html';
        }
        
        // Remove leading slash
        $path = ltrim($path, '/');
        
        // Remove query string
        $path = preg_replace('/\?.*$/', '', $path);
        
        // Add index.html if it's a directory or has no extension
        if (substr($path, -1) === '/') {
            $path .= 'index.html';
        } elseif (pathinfo($path, PATHINFO_EXTENSION) === '') {
            $path .= '/index.html';
        }
        
        return $path;
    }
    
    /**
     * Convert absolute URLs to relative
     */
    private function convert_urls_to_relative($html, $base_url) {
        $base_domain_escaped = preg_quote($this->base_domain, '/');
        
        // Replace absolute URLs with relative (preserve protocol for external links)
        $html = preg_replace(
            '/(href|src|action)=["\']https?:\/\/' . $base_domain_escaped . '([^"\']*)["\']/i',
            '$1="$2"',
            $html
        );
        
        // Fix protocol-relative URLs
        $html = preg_replace(
            '/(href|src|action)=["\']\/\/([^"\']*)["\']/i',
            '$1="https://$2"',
            $html
        );
        
        // Fix canonical URLs
        $html = preg_replace(
            '/<link\s+rel=["\']canonical["\']\s+href=["\']https?:\/\/' . $base_domain_escaped . '([^"\']*)["\']/i',
            '<link rel="canonical" href="$1"',
            $html
        );
        
        // Fix og:url
        $html = preg_replace(
            '/<meta\s+property=["\']og:url["\']\s+content=["\']https?:\/\/' . $base_domain_escaped . '([^"\']*)["\']/i',
            '<meta property="og:url" content="$1"',
            $html
        );
        
        return $html;
    }
    
    /**
     * Export all sitemaps
     */
    private function export_sitemaps() {
        // Main sitemap index
        $sitemap_urls = array(
            $this->site_url . '/sitemap_index.xml',
            $this->site_url . '/wp-sitemap.xml',
            $this->site_url . '/sitemap.xml'
        );
        
        foreach ($sitemap_urls as $sitemap_url) {
            $response = wp_remote_get($sitemap_url, array('timeout' => 30, 'sslverify' => false));
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $xml = wp_remote_retrieve_body($response);
                $xml = $this->convert_urls_to_relative($xml, $sitemap_url);
                
                $sitemap_path = parse_url($sitemap_url, PHP_URL_PATH);
                $sitemap_path = ltrim($sitemap_path, '/');
                if (empty($sitemap_path)) {
                    $sitemap_path = 'sitemap_index.xml';
                }
                
                $file_path = $this->export_dir . $sitemap_path;
                $dir = dirname($file_path);
                if (!file_exists($dir)) {
                    wp_mkdir_p($dir);
                }
                
                file_put_contents($file_path, $xml);
                $this->log("Exported sitemap: $sitemap_path");
                
                // If this is a sitemap index, get all sub-sitemaps
                if (strpos($sitemap_path, 'index') !== false || strpos($sitemap_path, 'sitemap.xml') !== false) {
                    preg_match_all('/<loc>(.*?)<\/loc>/', $xml, $matches);
                    if (!empty($matches[1])) {
                        foreach ($matches[1] as $sub_sitemap_url) {
                            $this->export_single_sitemap($sub_sitemap_url);
                        }
                    }
                }
                break; // Only process the first working sitemap
            }
        }
    }
    
    /**
     * Export a single sitemap file
     */
    private function export_single_sitemap($url) {
        $response = wp_remote_get($url, array('timeout' => 30, 'sslverify' => false));
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $xml = wp_remote_retrieve_body($response);
            $xml = $this->convert_urls_to_relative($xml, $url);
            
            $sitemap_path = parse_url($url, PHP_URL_PATH);
            $sitemap_path = ltrim($sitemap_path, '/');
            
            $file_path = $this->export_dir . $sitemap_path;
            $dir = dirname($file_path);
            if (!file_exists($dir)) {
                wp_mkdir_p($dir);
            }
            
            file_put_contents($file_path, $xml);
        }
    }
    
    /**
     * Export robots.txt
     */
    private function export_robots() {
        $robots_url = $this->site_url . '/robots.txt';
        $response = wp_remote_get($robots_url, array('timeout' => 30, 'sslverify' => false));
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $robots = wp_remote_retrieve_body($response);
            // Fix sitemap URLs to be relative
            $robots = preg_replace(
                '/Sitemap:\s*https?:\/\/[^\s]+/i',
                'Sitemap: /sitemap_index.xml',
                $robots
            );
            file_put_contents($this->export_dir . 'robots.txt', $robots);
        } else {
            // Create default robots.txt
            $robots = "User-agent: *\nAllow: /\n\nSitemap: /sitemap_index.xml\n";
            file_put_contents($this->export_dir . 'robots.txt', $robots);
        }
    }
    
    /**
     * Copy assets (images, CSS, JS)
     */
    private function copy_assets() {
        // Copy uploads directory
        $uploads_dir = WP_CONTENT_DIR . '/uploads/';
        $export_uploads_dir = $this->export_dir . 'wp-content/uploads/';
        
        if (file_exists($uploads_dir)) {
            $this->copy_directory($uploads_dir, $export_uploads_dir, array('simply-static', 'static-export'));
        }
        
        // Copy theme assets
        $theme_dir = get_template_directory();
        $export_theme_dir = $this->export_dir . 'wp-content/themes/' . get_template();
        $this->copy_directory($theme_dir, $export_theme_dir);
        
        // Copy plugin assets that are referenced in the HTML
        // We'll copy the essential ones that are likely used
        $plugins_dir = WP_PLUGIN_DIR;
        $export_plugins_dir = $this->export_dir . 'wp-content/plugins/';
        
        // List of plugins that typically have frontend assets
        $used_plugins = array(
            'elementor',
            'revslider',
            'woocommerce',
            'contact-form-7',
            'wordpress-seo',
            'wordpress-seo-premium'
        );
        
        foreach ($used_plugins as $plugin) {
            $plugin_path = $plugins_dir . '/' . $plugin;
            if (file_exists($plugin_path)) {
                $this->copy_directory($plugin_path, $export_plugins_dir . $plugin, array('node_modules', 'tests', 'tests'));
            }
        }
    }
    
    /**
     * Copy directory recursively
     */
    private function copy_directory($src, $dst, $exclude = array()) {
        if (!file_exists($src)) {
            return;
        }
        
        if (!file_exists($dst)) {
            wp_mkdir_p($dst);
        }
        
        $dir = opendir($src);
        if (!$dir) {
            return;
        }
        
        while (($file = readdir($dir)) !== false) {
            if ($file != '.' && $file != '..') {
                // Skip excluded directories
                if (in_array($file, $exclude)) {
                    continue;
                }
                
                $src_file = $src . '/' . $file;
                $dst_file = $dst . '/' . $file;
                
                if (is_dir($src_file)) {
                    $this->copy_directory($src_file, $dst_file, $exclude);
                } else {
                    // Only copy certain file types to save space
                    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    $allowed_extensions = array('css', 'js', 'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'woff', 'woff2', 'ttf', 'eot', 'ico', 'json', 'xml');
                    if (in_array($ext, $allowed_extensions)) {
                        $dst_dir = dirname($dst_file);
                        if (!file_exists($dst_dir)) {
                            wp_mkdir_p($dst_dir);
                        }
                        copy($src_file, $dst_file);
                    }
                }
            }
        }
        closedir($dir);
    }
    
    /**
     * Fix relative URLs in all exported files
     */
    private function fix_relative_urls() {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($this->export_dir),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        $count = 0;
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $ext = strtolower($file->getExtension());
                if (in_array($ext, array('html', 'xml', 'css', 'js'))) {
                    $content = file_get_contents($file->getPathname());
                    $original_content = $content;
                    
                    // Fix any remaining absolute URLs
                    $content = preg_replace(
                        '/https?:\/\/' . preg_quote($this->base_domain, '/') . '(\/[^"\'>\s]*)/',
                        '$1',
                        $content
                    );
                    
                    if ($content !== $original_content) {
                        file_put_contents($file->getPathname(), $content);
                        $count++;
                    }
                }
            }
        }
        
        $this->log("Fixed URLs in $count files");
    }
    
    /**
     * Log message
     */
    private function log($message) {
        if (php_sapi_name() === 'cli') {
            echo $message . "\n";
        } else {
            // For web interface, store in transient
            $logs = get_transient('static_export_logs') ?: array();
            $logs[] = date('H:i:s') . ' - ' . $message;
            set_transient('static_export_logs', $logs, HOUR_IN_SECONDS);
        }
    }
    
    /**
     * Get export directory
     */
    public function get_export_dir() {
        return $this->export_dir;
    }
}

