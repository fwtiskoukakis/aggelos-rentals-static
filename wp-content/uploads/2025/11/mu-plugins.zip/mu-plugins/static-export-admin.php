<?php
/**
 * Admin interface for static export
 * 
 * Adds a menu item under Tools to trigger the static site export
 * 
 * @package CustomStaticExporter
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Load the exporter class
require_once(__DIR__ . '/custom-static-export.php');

/**
 * Add admin menu
 */
add_action('admin_menu', function() {
    add_management_page(
        'Static Site Export',
        'Static Export',
        'manage_options',
        'static-export',
        'static_export_admin_page'
    );
});

/**
 * Admin page callback
 */
function static_export_admin_page() {
    // Handle export request
    if (isset($_POST['export_static']) && check_admin_referer('export_static_action', 'export_static_nonce')) {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die('You do not have sufficient permissions to access this page.');
        }
        
        // Set time limit for long-running export
        set_time_limit(0);
        ini_set('max_execution_time', 0);
        ini_set('memory_limit', '512M');
        
        // Start output buffering
        ob_start();
        
        echo '<div class="wrap">';
        echo '<h1>Static Site Export</h1>';
        echo '<div class="notice notice-info"><p><strong>Export in progress...</strong> This may take several minutes. Please do not close this page.</p></div>';
        echo '<div style="background: #f0f0f0; padding: 20px; border: 1px solid #ccc; max-height: 400px; overflow-y: auto; font-family: monospace; font-size: 12px;">';
        
        // Flush output
        ob_flush();
        flush();
        
        try {
            $exporter = new CustomStaticExporter();
            $export_dir = $exporter->export();
            
            // Get logs
            $logs = get_transient('static_export_logs') ?: array();
            delete_transient('static_export_logs');
            
            echo '</div>';
            echo '<div class="notice notice-success" style="margin-top: 20px;">';
            echo '<p><strong>Export completed successfully!</strong></p>';
            echo '<p>Export directory: <code>' . esc_html($export_dir) . '</code></p>';
            echo '<p>You can now copy the contents of this directory to your static hosting.</p>';
            echo '</div>';
            
            if (!empty($logs)) {
                echo '<details style="margin-top: 20px;">';
                echo '<summary><strong>Export Log</strong></summary>';
                echo '<div style="background: #f0f0f0; padding: 10px; margin-top: 10px; max-height: 300px; overflow-y: auto; font-family: monospace; font-size: 11px;">';
                echo '<pre>' . esc_html(implode("\n", $logs)) . '</pre>';
                echo '</div>';
                echo '</details>';
            }
            
        } catch (Exception $e) {
            echo '</div>';
            echo '<div class="notice notice-error" style="margin-top: 20px;">';
            echo '<p><strong>Export failed:</strong> ' . esc_html($e->getMessage()) . '</p>';
            echo '</div>';
        }
        
        echo '</div>';
        
        ob_end_flush();
        return;
    }
    
    // Display export form
    ?>
    <div class="wrap">
        <h1>Static Site Export</h1>
        
        <div class="card" style="max-width: 800px;">
            <h2>Export WordPress Site to Static HTML</h2>
            
            <p>This tool will export your entire WordPress site to static HTML files while preserving:</p>
            <ul style="list-style: disc; margin-left: 20px;">
                <li>All SEO metadata (Yoast SEO, Rank Math, etc.)</li>
                <li>Meta tags, Open Graph tags, Twitter cards</li>
                <li>Structured data (JSON-LD)</li>
                <li>All sitemaps (XML)</li>
                <li>robots.txt</li>
                <li>All images, CSS, and JavaScript files</li>
            </ul>
            
            <div class="notice notice-warning" style="margin: 20px 0;">
                <p><strong>Important Notes:</strong></p>
                <ul style="list-style: disc; margin-left: 20px;">
                    <li>This process may take several minutes depending on your site size</li>
                    <li>Do not close this page while the export is running</li>
                    <li>The export will be saved to: <code>wp-content/uploads/static-export-[timestamp]/</code></li>
                    <li>Contact forms will need to be replaced with a static-friendly solution (Formspree, Netlify Forms, etc.)</li>
                    <li>WooCommerce functionality (cart, checkout) will not work on a static site</li>
                </ul>
            </div>
            
            <form method="post" action="">
                <?php wp_nonce_field('export_static_action', 'export_static_nonce'); ?>
                <p>
                    <input type="submit" name="export_static" class="button button-primary button-large" value="Start Static Export" onclick="return confirm('This will start the export process. It may take several minutes. Continue?');">
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2>After Export</h2>
            <ol style="list-style: decimal; margin-left: 20px;">
                <li>Navigate to the export directory in <code>wp-content/uploads/</code></li>
                <li>Copy all files to your static hosting (Vercel, Netlify, etc.)</li>
                <li>Update your DNS to point to the new hosting</li>
                <li>Keep your email MX records unchanged (email will continue to work)</li>
                <li>Set up a contact form replacement service if needed</li>
            </ol>
        </div>
    </div>
    <?php
}

/**
 * Add admin notice if export was successful
 */
add_action('admin_notices', function() {
    if (isset($_GET['export_success']) && $_GET['export_success'] === '1') {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>Static export completed successfully! Check wp-content/uploads/static-export-*</p>';
        echo '</div>';
    }
});

